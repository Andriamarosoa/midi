"""Low-latency microphone-to-polyphonic-MIDI desktop application."""

from __future__ import annotations

import argparse
import csv
import json
import queue
import signal
import time
from pathlib import Path
import wave

import numpy as np

from src.polyphonic.decoder import PolyphonicDecoder, PolyphonicDecoderConfig
from src.polyphonic.tflite_runtime import PolyphonicBundle, TFLitePolyphonicModel
from src.product.audio_io import managed_input_stream
from src.product.backpressure import LiveBackpressure
from src.product.live import list_devices, make_sink, parse_device
from src.stream.onset_detector import AdaptiveOnsetDetector
from src.stream.ring_buffer import MonoRingBuffer


def _decoder(bundle: PolyphonicBundle) -> PolyphonicDecoder:
    metadata = bundle.metadata
    if "decoder" in metadata:
        return PolyphonicDecoder(PolyphonicDecoderConfig(**metadata["decoder"]))
    frame_threshold = float(metadata["frame_threshold"])
    return PolyphonicDecoder(PolyphonicDecoderConfig(
        midi_min=int(metadata["min_pitch"]),
        midi_max=int(metadata["max_pitch"]),
        maximum_polyphony=int(metadata["maximum_polyphony"]),
        frame_on_threshold=frame_threshold,
        strong_frame_threshold=min(0.95, max(0.80, frame_threshold + 0.25)),
        frame_off_threshold=max(0.05, frame_threshold * 0.60),
        onset_threshold=float(metadata["onset_threshold"]),
    ))


def run(args) -> int:
    bundle = PolyphonicBundle(args.artifacts)
    runtime = TFLitePolyphonicModel(bundle, args.threads)
    decoder = _decoder(bundle)
    sample_rate = int(bundle.metadata["sample_rate"])
    hop_samples = int(bundle.metadata["hop_samples"])
    window_samples = int(bundle.metadata["max_window_samples"])
    ring = MonoRingBuffer(window_samples)
    window = np.zeros(window_samples, np.float32)
    detector = AdaptiveOnsetDetector(
        sample_rate, hop_samples, fft_size=512,
        calibration_s=args.calibration_s,
    )
    backpressure = LiveBackpressure(
        max_backlog_hops=int(bundle.metadata.get("max_live_backlog_hops", 3))
    )
    for _ in range(20):
        runtime.infer(window)

    hops: queue.Queue[tuple[np.ndarray, float]] = queue.Queue(maxsize=64)
    overflow = 0
    audio_status_events = 0
    invalid_audio_blocks = 0
    queue_overflow_drops = 0
    backlog_discarded_hops = 0
    stopped = False
    stop_reason = "unknown"
    output_health_error = None
    last_valid_audio_callback = time.monotonic()
    runtime_error = None
    cleanup_errors: list[str] = []

    def callback(indata, frames, time_info, status) -> None:
        nonlocal overflow, audio_status_events, invalid_audio_blocks
        nonlocal queue_overflow_drops, last_valid_audio_callback
        if status:
            audio_status_events += 1
            overflow += 1
            return
        if frames != hop_samples or indata.ndim != 2:
            invalid_audio_blocks += 1
            overflow += 1
            return
        last_valid_audio_callback = time.monotonic()
        hop = np.asarray(indata[:, 0], np.float32).copy()
        try:
            hops.put_nowait((hop, time.perf_counter()))
        except queue.Full:
            overflow += 1
            queue_overflow_drops += 1
            # Keep latency bounded: discard the oldest hop and retain the
            # newest microphone audio instead of terminating the session.
            try:
                hops.get_nowait()
            except queue.Empty:
                pass
            try:
                hops.put_nowait((hop, time.perf_counter()))
            except queue.Full:
                pass

    def request_stop(signum, frame) -> None:
        nonlocal stopped, stop_reason
        stopped = True
        stop_reason = "signal"

    def discard_queued_hops() -> int:
        """Discard every queued hop without reordering concurrent callbacks."""
        removed = 0
        while True:
            try:
                hops.get_nowait()
                removed += 1
            except queue.Empty:
                break
        return removed

    signal.signal(signal.SIGINT, request_stop)
    sink = None
    audio_input_info = None
    debug_handle = None
    debug_writer = None
    record_handle = None
    record_buffer = bytearray()
    recorded_samples = 0
    try:
        sink = make_sink(args, sample_rate, hop_samples)
        if args.debug_csv:
            args.debug_csv.parent.mkdir(parents=True, exist_ok=True)
            debug_handle = args.debug_csv.open(
                "w", encoding="utf-8", newline=""
            )
        if args.record_wav:
            args.record_wav.parent.mkdir(parents=True, exist_ok=True)
            record_handle = wave.open(str(args.record_wav), "wb")
            record_handle.setnchannels(1)
            record_handle.setsampwidth(2)
            record_handle.setframerate(sample_rate)
    except Exception:
        if debug_handle is not None:
            try:
                debug_handle.close()
            except Exception as cleanup_exc:
                cleanup_errors.append(f"debug CSV: {cleanup_exc!r}")
        if record_handle is not None:
            try:
                record_handle.close()
            except Exception as cleanup_exc:
                cleanup_errors.append(f"WAV: {cleanup_exc!r}")
        if sink is not None:
            try:
                sink.close()
            except Exception as cleanup_exc:
                cleanup_errors.append(
                    f"sortie MIDI/audio: {cleanup_exc!r}"
                )
        if cleanup_errors:
            print("Erreurs de nettoyage: " + "; ".join(cleanup_errors))
        raise
    trace = None
    if args.debug_npz:
        trace = {
            "frame_index": [],
            "time_s": [],
            "visible_samples": [],
            "decoder_reset_before": [],
            "audio_active": [],
            "audio_onset": [],
            "rms_dbfs": [],
            "onset_detector_score": [],
            "frame_probability": [],
            "onset_probability": [],
            "harmonic_amplitude": [],
            "harmonic_offset_cents": [],
            "active_mask": [],
            "note_on_mask": [],
            "note_off_mask": [],
            "note_on_velocity": [],
        }
    calibrated_announced = False
    last_status = time.monotonic()
    started = time.monotonic()
    calibrated_frames = 0
    skipped = 0
    inference_ms: list[float] = []
    pipeline_ms: list[float] = []
    maximum_simultaneous_notes = 0
    processed_overflow = 0
    recoveries = 0
    recovery_events: list[dict[str, float | int | str]] = []
    decoder_reset_before = False
    minimum_context_samples = min(
        window_samples,
        max(hop_samples, int(bundle.metadata.get("minimum_window_samples", 512))),
    )
    print(
        f"Guitar MIDI Poly {bundle.metadata['product_version']} | "
        f"hop={hop_samples / sample_rate * 1000.0:.2f} ms | "
        f"max_notes={bundle.metadata['maximum_polyphony']}"
    )
    print("Reste silencieux pendant la calibration. Ctrl+C pour arreter.")
    try:
        with managed_input_stream(
            preferred_device=parse_device(args.audio_device),
            channels=1,
            samplerate=sample_rate,
            blocksize=hop_samples,
            dtype="float32",
            latency="low",
            callback=callback,
        ) as (_input_stream, audio_input_info):
            while not stopped:
                if args.duration_s and time.monotonic() - started >= args.duration_s:
                    stop_reason = "duration"
                    break
                output_health_error = sink.health_error()
                if output_health_error is not None:
                    try:
                        for event in decoder.panic():
                            sink.send(event)
                        sink.panic()
                    except Exception:
                        pass
                    stop_reason = "audio_output_error"
                    print(f"Sortie audio en erreur: {output_health_error}")
                    break
                try:
                    hop, captured_at = hops.get(timeout=0.25)
                except queue.Empty:
                    callback_stalled = (
                        not bool(getattr(_input_stream, "active", True))
                        or time.monotonic() - last_valid_audio_callback > 1.0
                    )
                    if callback_stalled:
                        try:
                            for event in decoder.panic():
                                sink.send(event)
                            sink.panic()
                        except Exception:
                            pass
                        stop_reason = "audio_input_stalled"
                        print(
                            "Le flux microphone ne fournit plus de blocs: "
                            "arret propre apres panic MIDI."
                        )
                        stopped = True
                        break
                    if overflow != processed_overflow:
                        discarded = discard_queued_hops()
                        backlog_discarded_hops += discarded
                        processed_overflow = overflow
                        for event in decoder.panic():
                            sink.send(event)
                        sink.panic()
                        ring.reset()
                        detector.reset_continuity()
                        backpressure = LiveBackpressure(
                            max_backlog_hops=int(
                                bundle.metadata.get("max_live_backlog_hops", 3)
                            )
                        )
                        recoveries += 1
                        decoder_reset_before = True
                        recovery_events.append({
                            "time_s": time.monotonic() - started,
                            "reason": "audio_callback_stall",
                            "discarded_hops": discarded,
                            "total_dropped_hops": (
                                overflow + backlog_discarded_hops
                            ),
                        })
                        print(
                            "Incident audio sans nouveau bloc: panic et "
                            "contexte causal reinitialise."
                        )
                    continue
                if overflow != processed_overflow:
                    discarded = 1 + discard_queued_hops()
                    backlog_discarded_hops += discarded
                    processed_overflow = overflow
                    for event in decoder.panic():
                        sink.send(event)
                    sink.panic()
                    ring.reset()
                    detector.reset_continuity()
                    backpressure = LiveBackpressure(
                        max_backlog_hops=int(
                            bundle.metadata.get("max_live_backlog_hops", 3)
                        )
                    )
                    recoveries += 1
                    decoder_reset_before = True
                    recovery_events.append({
                        "time_s": time.monotonic() - started,
                        "reason": "audio_callback",
                        "discarded_hops": discarded,
                        "total_dropped_hops": (
                            overflow + backlog_discarded_hops
                        ),
                    })
                    print(
                        "Surcharge audio recuperee: contexte causal reinitialise "
                        f"(dropped={overflow + backlog_discarded_hops})."
                    )
                    continue
                if args.audio_gain != 1.0:
                    hop *= args.audio_gain
                    np.clip(hop, -1.0, 1.0, out=hop)
                if record_handle is not None:
                    pcm = np.clip(hop, -1.0, 1.0)
                    record_buffer.extend(
                        np.rint(pcm * 32767.0).astype("<i2").tobytes()
                    )
                    recorded_samples += len(hop)
                    if len(record_buffer) >= sample_rate * 2:
                        record_handle.writeframesraw(record_buffer)
                        record_buffer.clear()
                ring.write(hop)
                onset_evidence = detector.process(hop)
                if not onset_evidence.calibrated:
                    continue
                if not calibrated_announced:
                    calibrated_announced = True
                    print("Calibration terminee. Le moteur polyphonique est actif.")
                calibrated_frames += 1
                if ring.available < minimum_context_samples:
                    continue
                ring.copy_latest_into(window)
                queue_depth = hops.qsize()
                try:
                    skip_inference = backpressure.decide(queue_depth)
                except RuntimeError:
                    # The queued audio is already too old for a live musical
                    # response. Discard it and resume from a clean context.
                    discarded = 1 + discard_queued_hops()
                    backlog_discarded_hops += discarded
                    for event in decoder.panic():
                        sink.send(event)
                    sink.panic()
                    ring.reset()
                    detector.reset_continuity()
                    backpressure = LiveBackpressure(
                        max_backlog_hops=int(
                            bundle.metadata.get("max_live_backlog_hops", 3)
                        )
                    )
                    recoveries += 1
                    decoder_reset_before = True
                    recovery_events.append({
                        "time_s": time.monotonic() - started,
                        "reason": "dangerous_backlog",
                        "discarded_hops": discarded,
                        "total_dropped_hops": (
                            overflow + backlog_discarded_hops
                        ),
                    })
                    print(
                        "Backlog audio recupere: blocs perimes abandonnes "
                        f"(dropped={overflow + backlog_discarded_hops})."
                    )
                    continue
                if skip_inference:
                    skipped += 1
                    continue
                prediction = runtime.infer(window, ring.available)
                audio_active = onset_evidence.rms >= max(
                    1e-5, onset_evidence.rms_threshold * 0.70
                )
                events = decoder.step(
                    prediction.frame_probability,
                    prediction.onset_probability,
                    prediction.harmonic_amplitude,
                    audio_active=audio_active,
                )
                for event in events:
                    sink.send(event)
                elapsed = (time.perf_counter() - captured_at) * 1000.0
                inference_ms.append(prediction.inference_ms)
                pipeline_ms.append(elapsed)
                active_notes = tuple(
                    bundle.metadata["min_pitch"] + int(index)
                    for index in np.flatnonzero(decoder.active)
                )
                maximum_simultaneous_notes = max(
                    maximum_simultaneous_notes, len(active_notes)
                )
                if trace is not None:
                    note_on_mask = np.zeros(decoder.classes, np.bool_)
                    note_off_mask = np.zeros(decoder.classes, np.bool_)
                    note_on_velocity = np.zeros(decoder.classes, np.uint8)
                    for event in events:
                        class_index = event.pitch - decoder.config.midi_min
                        if event.kind == "note_on":
                            note_on_mask[class_index] = True
                            note_on_velocity[class_index] = event.velocity
                        elif event.kind == "note_off":
                            note_off_mask[class_index] = True
                    trace["frame_index"].append(decoder.frame_index)
                    trace["time_s"].append(onset_evidence.time_s)
                    trace["visible_samples"].append(ring.available)
                    trace["decoder_reset_before"].append(decoder_reset_before)
                    trace["audio_active"].append(audio_active)
                    trace["audio_onset"].append(onset_evidence.is_onset)
                    trace["rms_dbfs"].append(onset_evidence.rms_dbfs)
                    trace["onset_detector_score"].append(onset_evidence.score)
                    trace["frame_probability"].append(
                        prediction.frame_probability.copy()
                    )
                    trace["onset_probability"].append(
                        prediction.onset_probability.copy()
                    )
                    trace["harmonic_amplitude"].append(
                        prediction.harmonic_amplitude.copy()
                    )
                    trace["harmonic_offset_cents"].append(
                        prediction.harmonic_offset_cents.copy()
                    )
                    trace["active_mask"].append(decoder.active.copy())
                    trace["note_on_mask"].append(note_on_mask)
                    trace["note_off_mask"].append(note_off_mask)
                    trace["note_on_velocity"].append(note_on_velocity)
                    decoder_reset_before = False
                if debug_handle is not None:
                    top_frame_indices = np.argsort(
                        prediction.frame_probability
                    )[-6:][::-1]
                    top_onset_indices = np.argsort(
                        prediction.onset_probability
                    )[-6:][::-1]
                    row = {
                        "frame": decoder.frame_index,
                        "time_s": onset_evidence.time_s,
                        "active_notes": " ".join(map(str, active_notes)),
                        "events": " ".join(
                            f"{event.kind}:{event.pitch}" for event in events
                        ),
                        "audio_active": int(audio_active),
                        "audio_onset": int(onset_evidence.is_onset),
                        "onset_detector_confidence": onset_evidence.confidence,
                        "onset_detector_armed": int(onset_evidence.armed),
                        "rms_dbfs": onset_evidence.rms_dbfs,
                        "rms_threshold": onset_evidence.rms_threshold,
                        "growth_threshold": onset_evidence.growth_threshold,
                        "flux_threshold": onset_evidence.flux_threshold,
                        "rms_growth": onset_evidence.rms_growth,
                        "spectral_flux": onset_evidence.spectral_flux,
                        "onset_detector_score": onset_evidence.score,
                        "top_frame": " ".join(
                            f"{bundle.metadata['min_pitch'] + int(index)}:"
                            f"{float(prediction.frame_probability[index]):.5f}"
                            for index in top_frame_indices
                        ),
                        "top_onset": " ".join(
                            f"{bundle.metadata['min_pitch'] + int(index)}:"
                            f"{float(prediction.onset_probability[index]):.5f}"
                            for index in top_onset_indices
                        ),
                        "inference_ms": prediction.inference_ms,
                        "pipeline_ms": elapsed,
                        "queue_depth": queue_depth,
                    }
                    if debug_writer is None:
                        debug_writer = csv.DictWriter(debug_handle, fieldnames=list(row))
                        debug_writer.writeheader()
                    debug_writer.writerow(row)
                now = time.monotonic()
                if now - last_status >= 1.0:
                    print(
                        f"notes={list(active_notes)} infer={prediction.inference_ms:.2f}ms "
                        f"pipeline={elapsed:.2f}ms skipped={skipped} "
                        f"dropped={overflow + backlog_discarded_hops}"
                    )
                    last_status = now
    except Exception as exc:
        runtime_error = repr(exc)
        if stop_reason == "unknown":
            stop_reason = "runtime_error"
        print(f"Erreur live polyphonique: {runtime_error}")
    finally:
        try:
            for event in decoder.panic():
                sink.send(event)
        except Exception as exc:
            cleanup_errors.append(f"panic decodeur: {exc!r}")
        try:
            sink.close()
        except Exception as exc:
            cleanup_errors.append(f"sortie MIDI/audio: {exc!r}")
        if debug_handle is not None:
            try:
                debug_handle.close()
            except Exception as exc:
                cleanup_errors.append(f"debug CSV: {exc!r}")
        if record_handle is not None:
            if record_buffer:
                try:
                    record_handle.writeframesraw(record_buffer)
                    record_buffer.clear()
                except Exception as exc:
                    cleanup_errors.append(f"ecriture WAV: {exc!r}")
            try:
                record_handle.close()
            except Exception as exc:
                cleanup_errors.append(f"fermeture WAV: {exc!r}")

    if stop_reason == "unknown":
        stop_reason = "cleanup_error" if cleanup_errors else "completed"

    if trace is not None:
        args.debug_npz.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            args.debug_npz,
            frame_index=np.asarray(trace["frame_index"], np.int64),
            time_s=np.asarray(trace["time_s"], np.float64),
            visible_samples=np.asarray(trace["visible_samples"], np.int32),
            decoder_reset_before=np.asarray(
                trace["decoder_reset_before"], np.bool_
            ),
            audio_active=np.asarray(trace["audio_active"], np.bool_),
            audio_onset=np.asarray(trace["audio_onset"], np.bool_),
            rms_dbfs=np.asarray(trace["rms_dbfs"], np.float32),
            onset_detector_score=np.asarray(
                trace["onset_detector_score"], np.float32
            ),
            frame_probability=np.asarray(
                trace["frame_probability"], np.float32
            ),
            onset_probability=np.asarray(
                trace["onset_probability"], np.float32
            ),
            harmonic_amplitude=np.asarray(
                trace["harmonic_amplitude"], np.float32
            ),
            harmonic_offset_cents=np.asarray(
                trace["harmonic_offset_cents"], np.float32
            ),
            active_mask=np.asarray(trace["active_mask"], np.bool_),
            note_on_mask=np.asarray(trace["note_on_mask"], np.bool_),
            note_off_mask=np.asarray(trace["note_off_mask"], np.bool_),
            note_on_velocity=np.asarray(
                trace["note_on_velocity"], np.uint8
            ),
            midi_min=np.asarray(bundle.metadata["min_pitch"], np.int16),
            midi_max=np.asarray(bundle.metadata["max_pitch"], np.int16),
            sample_rate=np.asarray(sample_rate, np.int32),
            hop_samples=np.asarray(hop_samples, np.int32),
        )

    if args.report_json:
        def stats(values: list[float]) -> dict[str, float | int | None]:
            data = np.asarray(values, np.float64)
            return {
                "count": int(len(data)),
                "mean": float(np.mean(data)) if len(data) else None,
                "p95": float(np.percentile(data, 95)) if len(data) else None,
                "max": float(np.max(data)) if len(data) else None,
            }
        audio_outputs = sink.diagnostics()
        output_latencies = [
            float(item["latency_ms"])
            for item in audio_outputs
            if item.get("direction") == "output" and item.get("latency_ms") is not None
        ]
        negotiated_audio_io_ms = (
            audio_input_info.latency_ms + sum(output_latencies)
            if audio_input_info is not None and output_latencies else None
        )
        report = {
            "duration_requested_s": args.duration_s,
            "calibrated_frames": calibrated_frames,
            "skipped_inferences": skipped,
            "skip_percent": 100.0 * skipped / max(calibrated_frames, 1),
            "audio_hops_dropped": overflow + backlog_discarded_hops,
            "audio_status_events": audio_status_events,
            "invalid_audio_blocks": invalid_audio_blocks,
            "queue_overflow_drops": queue_overflow_drops,
            "backlog_discarded_hops": backlog_discarded_hops,
            "overload_recoveries": recoveries,
            "overload_recovery_events": recovery_events,
            "stop_reason": stop_reason,
            "inference_ms": stats(inference_ms),
            "pipeline_ms": stats(pipeline_ms),
            "maximum_simultaneous_notes": maximum_simultaneous_notes,
            "recorded_wav": str(args.record_wav) if args.record_wav else None,
            "recorded_samples": recorded_samples,
            "debug_npz": str(args.debug_npz) if args.debug_npz else None,
            "audio_input": (
                audio_input_info.to_dict() if audio_input_info is not None else None
            ),
            "audio_outputs": audio_outputs,
            "negotiated_audio_io_ms": negotiated_audio_io_ms,
            "output_health_error": output_health_error,
            "runtime_error": runtime_error,
            "cleanup_errors": cleanup_errors,
        }
        args.report_json.parent.mkdir(parents=True, exist_ok=True)
        args.report_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
    shutdown_label = (
        "Arret avec erreur" if runtime_error is not None or cleanup_errors
        else "Arret propre"
    )
    print(
        f"{shutdown_label}. skipped={skipped}, "
        f"dropped={overflow + backlog_discarded_hops}, "
        f"recoveries={recoveries}"
    )
    if cleanup_errors:
        print("Erreurs de nettoyage: " + "; ".join(cleanup_errors))
    return 1 if runtime_error is not None or cleanup_errors else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Guitare polyphonique live vers MIDI")
    parser.add_argument(
        "--artifacts", type=Path,
        default=Path("artifacts/guitar_midi_polyphonic_v2_0_0"),
    )
    parser.add_argument("--list-devices", action="store_true")
    parser.add_argument("--audio-device")
    parser.add_argument("--midi-device")
    parser.add_argument("--midi-channel", type=int, default=1)
    parser.add_argument("--program", type=int, default=0)
    parser.add_argument("--console-midi", action="store_true")
    parser.add_argument("--no-midi", action="store_true")
    parser.add_argument(
        "--soundfont", type=Path,
        help="Active une sortie audio locale FluidSynth/WASAPI avec ce fichier SF2.",
    )
    parser.add_argument(
        "--audio-output-device",
        help="Index/nom de sortie audio; auto-WASAPI si omis.",
    )
    parser.add_argument("--synth-gain", type=float, default=0.65)
    parser.add_argument("--audio-gain", type=float, default=1.0)
    parser.add_argument("--calibration-s", type=float, default=1.0)
    parser.add_argument("--threads", type=int, choices=(1, 2, 4))
    parser.add_argument("--debug-csv", type=Path)
    parser.add_argument("--debug-npz", type=Path)
    parser.add_argument("--record-wav", type=Path)
    parser.add_argument("--report-json", type=Path)
    parser.add_argument("--duration-s", type=float)
    args = parser.parse_args()
    if args.list_devices:
        return list_devices()
    if not 1 <= args.midi_channel <= 16 or not 0 <= args.program <= 127:
        parser.error("Invalid MIDI channel/program.")
    if args.audio_gain <= 0 or args.calibration_s <= 0:
        parser.error("Gain and calibration must be positive.")
    if not 0.0 < args.synth_gain <= 5.0:
        parser.error("--synth-gain doit etre dans ]0, 5]")
    if args.soundfont is not None and not args.soundfont.is_file():
        parser.error(f"SoundFont introuvable: {args.soundfont}")
    if args.audio_output_device is not None and args.soundfont is None:
        parser.error("--audio-output-device requiert --soundfont")
    if args.duration_s is not None and args.duration_s <= 0:
        parser.error("--duration-s doit etre positif.")
    if args.debug_npz and not args.duration_s:
        parser.error("--debug-npz requires --duration-s to bound memory use.")
    if args.debug_npz and args.duration_s > 300:
        parser.error("--debug-npz is limited to captures of at most 300 seconds.")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
